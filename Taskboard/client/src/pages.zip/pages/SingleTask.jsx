export default function SingleTask(){
    return <h1>Single Task</h1>
}