export default function Tasks(){
    return <h1>Tasks</h1>
}

//  function UpdateTask(){
//     return<h1>Update Task</h1>
// }


